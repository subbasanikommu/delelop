# aemproject
Used to test DevOps tools
Modified to check the webhooks and mvn build as well
