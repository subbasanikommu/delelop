package com.aem.geeks.core.services;

public interface OSGiConfigModule {
    public int getServiceId() ;
    public String getServiceName();
    public String getServiceURL() ;
}
