package com.aem.geeks.core.services;

public interface MultiService {
public String getName();
}
