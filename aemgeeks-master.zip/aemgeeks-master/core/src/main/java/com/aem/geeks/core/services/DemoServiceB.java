package com.aem.geeks.core.services;

import java.util.List;

public interface DemoServiceB {
    public List<String> getPages();
    public String getNameWithReference();
}
